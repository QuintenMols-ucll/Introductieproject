ECHO is on.
